#ifndef __MATROXFB_ACCEL_H__
#define __MATROXFB_ACCEL_H__

#include "matroxfb_base.h"

void matrox_cfbX_init(WPMINFO2);

#endif
